# Privacy Policy for Kid Billionaire / Richie Diamond Vault
Last updated: October 2026
This game is COPPA compliant, family-safe, and collects zero personal data. It runs 100% offline.
